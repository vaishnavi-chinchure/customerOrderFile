﻿public class Customer
{
    public Guid CustomerID { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public DateTime DOB { get; set; }

    public ICollection<Order> Orders { get; set; }

    public static implicit operator Guid(Customer v)
    {
        throw new NotImplementedException();
    }
}

public class Order
{
    public int OrderID { get; set; }
    public Guid CustomerID { get; set; }
    public string ItemName { get; set; }
    public decimal ItemPrice { get; set; }

    public Customer Customer { get; set; }
}
