﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

public class CustomerResponse
{
    public List<CustomerWrapper> Values { get; set; }
}

public class CustomerWrapper
{
    public string CustomerID { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public DateTime Dob { get; set; }
    public List<OrderWrapper> orders { get; set; }
}

public class OrderCollection
{
    [JsonProperty("$id")]
    public string Id { get; set; }

    [JsonProperty("$value")]
    public List<OrderWrapper> Value { get; set; }
}


public class OrderWrapper
{
    public int orderID { get; set; }
    public string customerID { get; set; }
    public string itemName { get; set; }
    public decimal itemPrice { get; set; }
}

