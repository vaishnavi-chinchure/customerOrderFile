﻿namespace COCLASSLIBRARY
{
    public class Class1
    {

    }
}
