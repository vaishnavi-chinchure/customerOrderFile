﻿using Microsoft.EntityFrameworkCore;

namespace COAPI.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly COContext _context;

        public CustomerRepository(COContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Customer>> GetCustomersWithOrdersAsync()
        {
            return await _context.Customers
                .Include(c => c.Orders)
                .ToListAsync();
        }

        public async Task<Customer> GetCustomerWithOrdersAsync(string customerid)
        {
            return _context.Customers.Include(c => c.Orders).FirstOrDefault(c => c.CustomerID == new Guid(customerid));
               // .Include(c => c.Orders).FirstOrDefault();
              
        }


    }


}
